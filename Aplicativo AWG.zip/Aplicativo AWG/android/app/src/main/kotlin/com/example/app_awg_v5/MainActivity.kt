package com.example.app_awg_v5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
